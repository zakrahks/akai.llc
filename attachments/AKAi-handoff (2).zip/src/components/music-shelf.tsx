import { useState } from "react";
import { ARTIST, releases } from "@/data/tracks";
import { formatPrice } from "@/data/catalog";
import { playRelease, togglePlayback, usePlayer } from "@/components/player-store";
import { Hypercube } from "@/components/hypercube";

const FILTERS = ["All", "Beat", "Song"] as const;
type Filter = (typeof FILTERS)[number];

export function MusicShelf({ onAdd }: { onAdd: (line: string) => void }) {
  const [filter, setFilter] = useState<Filter>("All");
  const activeId = usePlayer((state) => state.activeId);
  const playing = usePlayer((state) => state.playing);
  const shown = releases.filter((release) => filter === "All" || release.kind === filter);

  const empty =
    filter === "Beat" ? "No beats yet." : filter === "Song" ? "No songs yet." : "No releases yet.";

  return (
    <section className="section" id="music" aria-label="Music">
      <div className="section-head">
        <p className="eyebrow">02 / Music</p>
        <div className="artist-lockup">
          <h2>{ARTIST.name}</h2>
          <p className="verified">Verified artist</p>
        </div>
      </div>
      <p className="rights">{ARTIST.rights}</p>

      <div className="hyper-stage">
        <Hypercube playing={playing} />
        <p className="hyper-caption">{playing ? "Moving with the file" : "Hypercube shelf · idle"}</p>
      </div>

      <ul className="shelf-rules">
        <li className="shelf-rule">
          <strong>Listen</strong>
          <span>Plays in the bar. The cube above moves with the file.</span>
        </li>
        <li className="shelf-rule">
          <strong>Lease</strong>
          <span>Non-exclusive. The price sits on the release and goes in the bag.</span>
        </li>
        <li className="shelf-rule">
          <strong>Exclusive</strong>
          <span>One buyer. The price sits on the release and goes in the bag.</span>
        </li>
      </ul>

      <div className="filters" role="group" aria-label="Catalog">
        {FILTERS.map((item) => (
          <button
            key={item}
            type="button"
            className="pill"
            aria-pressed={filter === item}
            onClick={() => setFilter(item)}
          >
            {item === "All" ? "All" : item === "Beat" ? "Beats" : "Songs"}
          </button>
        ))}
      </div>

      {shown.length === 0 ? (
        <div className="shelf-empty">
          <h3>{empty}</h3>
          <p>Nothing is listed yet. When a release is added, it can play in the bar or go in the bag.</p>
        </div>
      ) : (
        <ul className="release-list">
          {shown.map((release) => {
            const current = activeId === release.id && playing;
            const meta = [
              release.kind,
              release.bpm ? `${release.bpm} bpm` : null,
              release.musicalKey,
              release.artist !== ARTIST.name ? release.artist : null,
            ]
              .filter(Boolean)
              .join(" · ");
            return (
              <li key={release.id} className="release">
                <button
                  type="button"
                  className="action-btn"
                  aria-pressed={current}
                  onClick={() => {
                    if (current) togglePlayback();
                    else void playRelease(release.id);
                  }}
                >
                  {current ? "Pause" : "Play"}
                </button>
                <div className="release-copy">
                  <p className="eyebrow">{meta}</p>
                  <h3>{release.title}</h3>
                </div>
                <div className="offers">
                  {release.offers.length === 0 ? (
                    <p className="sample-note">Sample · not for sale</p>
                  ) : (
                    release.offers.map((offer) => (
                      <button
                        key={offer.kind}
                        type="button"
                        className={offer.kind === "exclusive" ? "add-btn" : "pill"}
                        onClick={() => onAdd(`${release.title} · ${offer.label}`)}
                      >
                        {offer.label} · {formatPrice(offer.price, offer.currency)}
                      </button>
                    ))
                  )}
                </div>
              </li>
            );
          })}
        </ul>
      )}
    </section>
  );
}
