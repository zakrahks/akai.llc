# AK Ai — build log

Date: 30 September 2026
Studio mark: **AK Ai**
Music credit: **nerbous** (verified artist; all music and rights owned by nerbous)
Shape: one page. A holding studio, not a single-product brand.

This file is the handoff. It records what was built, why, which files own which behavior, and how to add the next venture or the next track without a redesign.

---

## 1. What this site is

A flexible shell for more than one business.

| Section | Anchor | Role |
|---|---|---|
| Header | — | Sticky. Mark “AK Ai”. Nav: Shop, Music, Ventures, Goods, About. Bag count. |
| Mast | above `#shop` | Centered “AKAi LLC” in Syne, with jump buttons under it. |
| Stage | `#shop` | First screen. Procedural 3D hoodie. Color, cloth, size, lights, spin, reset, add to bag. |
| Music | `#music` | Shelf for beats and songs by nerbous. Jellyfish is a sample: play only, no price. |
| Ventures | `#ventures` | Card grid. Apparel, Music, Software, Media, Services, Experiments. |
| Goods | `#goods` | Shirt grid. Square tiles, name, price. Rows come from `shirts` in `src/data/catalog.ts`. A tile opens that cut and color on the stage. |
| About | `#about` | Three lines. No manifesto. |
| Footer | — | Mark + year. |
| Player | fixed bottom | Stays up while someone shops. Play, a small hypercube, seek, volume. |

Clothing on the stage is demo content. Music is a second lane, not the identity of the site. New businesses are new cards in the ventures list, not a new layout.

There is no account system, no payment, no persistent cart, and no checkout. “Add to bag” only increments a count on this page and shows a short toast.

---

## 2. Decisions, in order

1. **Stop locking the site to one brand.** An earlier pass was drifting toward a single clothing story. The correction was: broad holding studio. Apparel is one card among others.
2. **First screen stays the 3D stage.** Commerce chrome frames the canvas. It does not cover the model. Controls work with a finger, not only hover. Hit targets are at least 44px.
3. **The garment is procedural.** Three.js builds a stylized hoodie from boxes (torso, sleeves, hood, pocket, hem). No GLB, no scanned garment, no photoreal person.
4. **Music is the ability, plus one sample.** nerbous owns the rights. Jellyfish is on the shelf to play. It has no price and no bag button. Lease and exclusive stay wired for a later release that includes offers.
5. **One real sample, no invented catalog.** A one-second test tone proved the player, then it was deleted. The artist then supplied Jellyfish. That file is the only track. `public/audio/jellyfish.m4a`. Offers are empty, so the row says “Sample · not for sale.”
6. **The player must not wreck the phone layout.** On a 390px screen the dock is one short bar. Seek and volume live behind an Audio control so Add to bag on the stage still sits above the bar.
7. **The visualizer should not be a neat bar graph.** It is a tesseract: overlapping wire shelves that drift on their own and react when a file plays. The clothing stage stays the quieter object.

---

## 3. Page behavior

### Stage

- Orbit: drag or one finger. Damping on. Auto-rotate starts on, pauses while dragging, resumes after release. Respects reduced motion (spin starts off).
- Zoom: wheel and pinch, clamped so the camera cannot pass through the model.
- Reset restores the saved hero framing. Keyboard: `R` reset, `Space` toggles spin (ignored while typing or on a button).
- Lights: Warm / Neutral / Cool, plus key, fill, rim, and environment sliders.
- Variants: Ink, Bone, Brass, Forest, Clay. Cloth: Matte cotton or Heavy fleece. Sizes S–XL.
- Piece switches the object on the stage: Hoodie, Tee, or Vessel. Vessel is not clothing. Hoodie and Tee can hide the plaster figure (neck and head). New objects are another entry in `stagePieces` in `src/data/catalog.ts`.
- Studio slider (under the swatches) shifts type, buttons, shelf rules, the hypercube, the key light, and — while it is being dragged — the cloth. A named swatch still sets that exact cloth color and, if the color has a hue, moves the slider to match.

### Music shelf

- Header: nerbous, “Verified artist”, rights line.
- A large hypercube under the credit. Four overlapping projections, brass and bone wire, short trails. Caption says idle until a file is playing.
- Three rules, always visible: Listen (plays in the bar, the cube moves with the file), Lease (non-exclusive, bag), Exclusive (one buyer, bag).
- Filters: All / Beats / Songs. Beats is empty. Songs shows Jellyfish.
- A release with offers shows Lease and Exclusive prices. A release with none shows “Sample · not for sale” and does not touch the bag.

### Player

- Fixed to the bottom of the viewport on every section.
- Idle, with nothing selected: “Shelf empty” and the artist name, plus a small hypercube.
- Play with no releases at all: the status line says the shelf is empty. It does not pretend to play.
- Play with a file: HTML audio into an AnalyserNode. Bass scales the cube. Treble pushes corners. The track keeps playing if the visitor scrolls back to the hoodie.
- End of a track advances to the next release, or stops if it was the last.
- Audio opens Seek (disabled until a file has a duration) and Volume.
- Desktop also shows previous / next. Those are hidden on small screens to keep the bar one row.

### Bag

Local React state only. Hoodie adds `Heavy Hoodie · {color} · {size}`. A release adds `{title} · Lease` or `{title} · Exclusive`. Toast sits above the player for about two seconds.

---

## 4. Files a collaborator should open

App code. Platform helpers under `src/lib/auth`, `src/lib/db`, and `src/lib/app-data` are prewired and were not used. Auth and the database stay off.

| File | Owns |
|---|---|
| `src/routes/index.tsx` | The page. Stage state, lights, bag, toast, keyboard. Composes the shelf and the dock. |
| `src/routes/__root.tsx` | Document shell, fonts (Schibsted Grotesk + IBM Plex Mono), title “AK Ai”. |
| `src/styles.css` | Tokens and layout. Dark studio. No second visual language. |
| `src/data/catalog.ts` | `demoProduct` and the `ventures` array. Adding a business is a new object here. |
| `src/data/tracks.ts` | Artist credit and `releases`. Adding a beat or song is a new object here. |
| `src/components/stage-canvas.ts` | Three.js scene, hoodie mesh, lights, orbit, camera home. |
| `src/components/product-stage.tsx` | Mounts the canvas on the client. Passes color, cloth, spin, and lights without remounting. |
| `src/components/music-shelf.tsx` | Shelf UI. Filters, empty state, release rows, bag callbacks, large hypercube. |
| `src/components/hypercube.tsx` | Tesseract draw. Shared by the music stage and the bottom bar. |
| `src/components/player-dock.tsx` | The bar. |
| `src/components/player-store.ts` | Playback. Zustand so the clock does not rerender the 3D stage. Web Audio graph created on the first gesture. |

### How the 3D stage stays in sync

`ProductStage` keeps the latest props in a ref. `mountStage` runs once. Color, cloth, spin, and lights update the existing meshes. That avoids a flash and a camera jump when a swatch changes.

### How audio stays off the server

`player-store.ts` constructs `Audio` and `AudioContext` only inside a function that runs after a click. The shelf and the dock render the same on the server and the client. Nothing in the catalog is fetched from a network.

---

## 5. How to add a track

Put the audio file where the site can serve it, for example `public/audio/track-id.mp3`. Then append to `releases` in `src/data/tracks.ts`:

```ts
{
  id: "track-id",
  title: "Title",
  kind: "Beat", // or "Song"
  artist: ARTIST.name,
  bpm: 140,
  musicalKey: "A minor",
  src: "/audio/track-id.mp3",
  offers: [lease(29), exclusive(299)],
}
```

`src: null` lists a release that can be bagged but will not play. The player says the file is not attached yet.

No layout edit is required. The row, the filters, the player title, the hypercube, and the bag line all read this array.

Do not drop in music the artist did not supply. The rights line on the page says the catalog belongs to nerbous.

---

## 6. How to add another business

Append to `ventures` in `src/data/catalog.ts`:

```ts
{
  id: "short-id",
  name: "Name",
  pitch: "One sentence.",
  status: "Live", // or "Building" or "Idea"
  cta: "Short verb",
  href: "#somewhere-on-this-page",
}
```

The grid is driven by that array. Six cards today: Apparel (Live), Music (Building), Software (Building), Media (Building), Services (Idea), Experiments (Idea).

A new section on the same page gets an `id` and a nav link in `src/routes/index.tsx`. It should not replace the stage as the first screen unless that is an explicit choice.

---

## 7. Look

- Ground `#0c0b0a`, surface `#141210`, type `#f4efe6`, muted `#9c9488`, line `#2c2824`, accent `#c9a36a`.
- Live status is a muted green. Building uses the brass accent. Idea is gray.
- Grotesque for names. Mono for labels, prices, nav, and the player clock.
- Motion is about 200ms on controls. The hypercube is the one place that keeps moving.
- Not used: purple SaaS gradients, emoji icons, glassmorphism as decoration, neon, stock-photo collage, lorem.

---

## 8. What was verified

- Phone 390×844: stage canvas present, Add to bag sits above the player, no horizontal scroll, header stays one row.
- Jellyfish: Play became Pause, the bar read `nerbous · Song`, the clock moved (about 5:10), and the cube caption switched to “Moving with the file.” No price, no bag line.
- Beats filter still shows the empty state. Songs shows Jellyfish.
- `npm run typecheck` and `npm run build` passed after the sample was added.
- A production preview matched the dev page: canvas present, no console errors, no horizontal overflow, desktop and mobile. The audio file is in the built static output.

Known non-blocker: Three.js logs that `PCFSoftShadowMap` was removed and `PCFShadowMap` is used. It is a warning, not a failed render.

---

## 9. Explicitly not built

- No checkout, no card charge, no accounts, no saved cart.
- Jellyfish is a sample. It is not priced.
- No supplier, printer, or legal-entity names.
- No second page and no CMS.
- The site was not relabeled as a game for share cards. The 3D canvas makes an automated check ask for a game unfurl. That would misrepresent a studio shop, so it was left as a studio.

---

## 10. Stack

React 19, TanStack Start, Tailwind v4, Three.js for the stage, Zustand for the player, Web Audio for the meter. Dev server is the live preview. Production build targets Vercel via the existing app setup.

---

## 11. Hypercube shelf

`src/components/hypercube.tsx` draws a tesseract: 16 vertices, the edges of a 4D cube, projected into the page and rotated through each other.

The music section holds four copies at different sizes and phases, with a short trail. Idle, they drift. While a file plays they turn at a steady slow rate, about one pass a minute. Bass thickens the lines and tints the white ones toward the studio color. It does not speed the spin. Reduced motion freezes the spin.

The bottom bar keeps two smaller copies so the same object stays visible on the hoodie. Reduced motion freezes the spin.
