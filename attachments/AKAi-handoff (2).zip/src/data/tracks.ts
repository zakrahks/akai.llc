export type TrackKind = "Beat" | "Song";
export type OfferKind = "lease" | "exclusive";

export type Offer = {
  kind: OfferKind;
  label: string;
  price: number;
  currency: string;
  note: string;
};

export type Release = {
  id: string;
  title: string;
  kind: TrackKind;
  artist: string;
  bpm: number | null;
  musicalKey: string | null;
  /** Same-origin path or URL. Null until the audio file is added. */
  src: string | null;
  offers: Offer[];
};

export const ARTIST = {
  name: "nerbous",
  verified: true,
  rights: "All music and rights are owned by nerbous.",
} as const;

export function lease(price: number): Offer {
  return {
    kind: "lease",
    label: "Lease",
    price,
    currency: "USD",
    note: "Non-exclusive.",
  };
}

export function exclusive(price: number): Offer {
  return {
    kind: "exclusive",
    label: "Exclusive",
    price,
    currency: "USD",
    note: "One buyer.",
  };
}

/**
 * Catalog. A release with an empty offers list can play, but it is not for sale.
 *
 * {
 *   id: "track-id",
 *   title: "Title",
 *   kind: "Beat",
 *   artist: ARTIST.name,
 *   bpm: 140,
 *   musicalKey: "A minor",
 *   src: "/audio/track-id.mp3",
 *   offers: [lease(29), exclusive(299)],
 * }
 */
export const releases: Release[] = [
  {
    id: "jellyfish",
    title: "Jellyfish",
    kind: "Song",
    artist: ARTIST.name,
    bpm: null,
    musicalKey: null,
    src: "/audio/jellyfish.m4a",
    offers: [],
  },
];
