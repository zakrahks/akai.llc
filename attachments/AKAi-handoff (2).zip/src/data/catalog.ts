export type MaterialId = "cotton" | "fleece";
export type ModelType = "hoodie" | "tee" | "vessel";
export type VentureStatus = "Live" | "Building" | "Idea";

export type Variant = {
  id: string;
  label: string;
  color: string;
  material: MaterialId;
};

export type ProductConfig = {
  id: string;
  name: string;
  price: number;
  currency: string;
  spec: string;
  sizes: string[];
  variants: Variant[];
  modelType: ModelType;
};

export type Venture = {
  id: string;
  name: string;
  pitch: string;
  status: VentureStatus;
  cta: string;
  href: string;
};

export type StagePiece = {
  id: string;
  label: string;
  name: string;
  price: number;
  spec: string;
  modelType: ModelType;
  apparel: boolean;
  sizes: string[];
};

export const stagePieces: StagePiece[] = [
  {
    id: "hoodie",
    label: "Hoodie",
    name: "Heavy Hoodie",
    price: 84,
    spec: "Studio piece. Recolor the cloth. The shell stays.",
    modelType: "hoodie",
    apparel: true,
    sizes: ["S", "M", "L", "XL"],
  },
  {
    id: "tee",
    label: "Tee",
    name: "Block Tee",
    price: 42,
    spec: "Same stage, shorter cut. The figure is optional.",
    modelType: "tee",
    apparel: true,
    sizes: ["S", "M", "L", "XL"],
  },
  {
    id: "vessel",
    label: "Vessel",
    name: "Studio Vessel",
    price: 64,
    spec: "Not clothing. Same light, same color, different object.",
    modelType: "vessel",
    apparel: false,
    sizes: [],
  },
];

export const MATERIALS: { id: MaterialId; label: string }[] = [
  { id: "cotton", label: "Matte cotton" },
  { id: "fleece", label: "Heavy fleece" },
];

export const demoProduct: ProductConfig = {
  id: "stage-hoodie",
  name: "Heavy Hoodie",
  price: 84,
  currency: "USD",
  spec: "Studio piece. Recolor the cloth. The shell stays.",
  sizes: ["S", "M", "L", "XL"],
  modelType: "hoodie",
  variants: [
    { id: "ink", label: "Ink", color: "#1c1e24", material: "fleece" },
    { id: "bone", label: "Bone", color: "#e6dcc8", material: "cotton" },
    { id: "brass", label: "Brass", color: "#b58958", material: "fleece" },
    { id: "forest", label: "Forest", color: "#2f4038", material: "fleece" },
    { id: "clay", label: "Clay", color: "#8d4d3c", material: "cotton" },
  ],
};

export const ventures: Venture[] = [
  {
    id: "apparel",
    name: "Apparel",
    pitch: "Garments on the stage. Color, cloth, size. One vertical among others.",
    status: "Live",
    cta: "Open the stage",
    href: "#shop",
  },
  {
    id: "music",
    name: "Music",
    pitch: "Beats and songs by nerbous. The player stays up while the rest of the shop is open.",
    status: "Building",
    cta: "Open the shelf",
    href: "#music",
  },
  {
    id: "software",
    name: "Software",
    pitch: "Tools and products shipped from the same desk.",
    status: "Building",
    cta: "Hold the slot",
    href: "#about",
  },
  {
    id: "media",
    name: "Media",
    pitch: "Writing, clips, and a public record of the work.",
    status: "Building",
    cta: "Read later",
    href: "#about",
  },
  {
    id: "services",
    name: "Services",
    pitch: "Work done for other people. Scoped. Not a storefront.",
    status: "Idea",
    cta: "Leave it open",
    href: "#about",
  },
  {
    id: "experiments",
    name: "Experiments",
    pitch: "Things that are not a company yet. They still get a card.",
    status: "Idea",
    cta: "Keep the grid",
    href: "#about",
  },
];

export type Shirt = {
  id: string;
  name: string;
  price: number;
  color: string;
  pieceId: string;
  variantId: string;
};

/** Pretend rack. Another shirt is another object in this list. */
export const shirts: Shirt[] = [
  { id: "ink-tee", name: "Ink Tee", price: 42, color: "#1c1e24", pieceId: "tee", variantId: "ink" },
  { id: "bone-tee", name: "Bone Tee", price: 42, color: "#e6dcc8", pieceId: "tee", variantId: "bone" },
  { id: "brass-tee", name: "Brass Tee", price: 42, color: "#b58958", pieceId: "tee", variantId: "brass" },
  { id: "forest-tee", name: "Forest Tee", price: 48, color: "#2f4038", pieceId: "tee", variantId: "forest" },
  { id: "clay-tee", name: "Clay Tee", price: 42, color: "#8d4d3c", pieceId: "tee", variantId: "clay" },
  { id: "ink-hood", name: "Ink Hoodie", price: 84, color: "#1c1e24", pieceId: "hoodie", variantId: "ink" },
  { id: "bone-hood", name: "Bone Hoodie", price: 84, color: "#e6dcc8", pieceId: "hoodie", variantId: "bone" },
  { id: "brass-hood", name: "Brass Hoodie", price: 84, color: "#b58958", pieceId: "hoodie", variantId: "brass" },
];

export function formatPrice(price: number, currency: string) {
  return new Intl.NumberFormat("en-US", {
    style: "currency",
    currency,
    maximumFractionDigits: 0,
  }).format(price);
}
