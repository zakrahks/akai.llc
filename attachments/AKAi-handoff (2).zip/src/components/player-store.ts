import { create } from "zustand";
import { releases, type Release } from "@/data/tracks";

type PlayerState = {
  activeId: string | null;
  playing: boolean;
  currentTime: number;
  duration: number;
  volume: number;
  message: string | null;
};

type Engine = {
  audio: HTMLAudioElement;
  read: (out: Uint8Array) => boolean;
  play: (src: string) => Promise<void>;
  pause: () => void;
};

let engine: Engine | null = null;

function createEngine(): Engine {
  const audio = new Audio();
  audio.preload = "auto";
  audio.crossOrigin = "anonymous";
  audio.volume = usePlayer.getState().volume;

  let ctx: AudioContext | null = null;
  let analyser: AnalyserNode | null = null;
  let connected = false;

  audio.ontimeupdate = () => {
    usePlayer.setState({ currentTime: audio.currentTime });
  };
  audio.onloadedmetadata = () => {
    const duration = Number.isFinite(audio.duration) ? audio.duration : 0;
    usePlayer.setState({ duration });
  };
  audio.onended = () => {
    const { activeId } = usePlayer.getState();
    const index = releases.findIndex((item) => item.id === activeId);
    const next = releases[index + 1];
    if (next) {
      void playRelease(next.id);
      return;
    }
    usePlayer.setState({ playing: false });
  };
  audio.onerror = () => {
    usePlayer.setState({ playing: false, message: "That file did not load." });
  };

  function ensureGraph() {
    if (!ctx) {
      const Context = window.AudioContext || (window as typeof window & { webkitAudioContext?: typeof AudioContext }).webkitAudioContext;
      ctx = new Context();
      analyser = ctx.createAnalyser();
      analyser.fftSize = 128;
      analyser.smoothingTimeConstant = 0.82;
    }
    if (!connected && analyser) {
      const source = ctx.createMediaElementSource(audio);
      source.connect(analyser);
      analyser.connect(ctx.destination);
      connected = true;
    }
    return ctx;
  }

  return {
    audio,
    read(out) {
      if (!analyser) return false;
      analyser.getByteFrequencyData(out as Uint8Array<ArrayBuffer>);
      return true;
    },
    async play(src) {
      const context = ensureGraph();
      const absolute = new URL(src, window.location.href).href;
      if (audio.src !== absolute) {
        audio.src = src;
        usePlayer.setState({ currentTime: 0, duration: 0 });
      }
      if (context.state === "suspended") await context.resume();
      await audio.play();
    },
    pause() {
      audio.pause();
    },
  };
}

function getEngine() {
  if (!engine) engine = createEngine();
  return engine;
}

export const usePlayer = create<PlayerState>(() => ({
  activeId: null,
  playing: false,
  currentTime: 0,
  duration: 0,
  volume: 0.85,
  message: null,
}));

export function readFrequencies(out: Uint8Array) {
  return engine?.read(out) ?? false;
}

export function releaseById(id: string | null): Release | null {
  if (!id) return null;
  return releases.find((item) => item.id === id) ?? null;
}

export async function playRelease(id: string) {
  const release = releases.find((item) => item.id === id);
  if (!release) return;
  usePlayer.setState({ activeId: id, message: null });
  if (!release.src) {
    if (engine) engine.pause();
    usePlayer.setState({
      playing: false,
      currentTime: 0,
      duration: 0,
      message: "No audio file on this release yet.",
    });
    return;
  }
  try {
    await getEngine().play(release.src);
    usePlayer.setState({ playing: true, message: null });
  } catch {
    usePlayer.setState({ playing: false, message: "That file did not play." });
  }
}

export function togglePlayback() {
  const { activeId, playing } = usePlayer.getState();
  if (playing) {
    getEngine().pause();
    usePlayer.setState({ playing: false });
    return;
  }
  if (activeId) {
    void playRelease(activeId);
    return;
  }
  const first = releases.find((item) => item.src) ?? releases[0];
  if (!first) {
    usePlayer.setState({ message: "No releases on the shelf yet." });
    return;
  }
  void playRelease(first.id);
}

export function stepRelease(direction: -1 | 1) {
  if (releases.length === 0) {
    usePlayer.setState({ message: "No releases on the shelf yet." });
    return;
  }
  const { activeId } = usePlayer.getState();
  const index = Math.max(0, releases.findIndex((item) => item.id === activeId));
  const next = releases[(index + direction + releases.length) % releases.length];
  void playRelease(next.id);
}

export function seekPlayback(time: number) {
  if (!engine?.audio.src) return;
  const duration = usePlayer.getState().duration;
  const next = Math.min(Math.max(0, time), duration || 0);
  engine.audio.currentTime = next;
  usePlayer.setState({ currentTime: next });
}

export function setPlaybackVolume(volume: number) {
  const next = Math.min(1, Math.max(0, volume));
  usePlayer.setState({ volume: next });
  if (engine) engine.audio.volume = next;
}
