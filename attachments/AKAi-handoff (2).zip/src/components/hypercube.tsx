import { useEffect, useRef } from "react";
import { readFrequencies } from "@/components/player-store";

const VERTS: number[][] = [];
const EDGES: [number, number][] = [];

for (let index = 0; index < 16; index += 1) {
  VERTS.push([(index & 1) * 2 - 1, (index & 2) - 1, ((index & 4) >> 1) - 1, ((index & 8) >> 2) - 1]);
}

for (let i = 0; i < 16; i += 1) {
  for (let j = i + 1; j < 16; j += 1) {
    let diff = 0;
    for (let axis = 0; axis < 4; axis += 1) {
      if (VERTS[i][axis] !== VERTS[j][axis]) diff += 1;
    }
    if (diff === 1) EDGES.push([i, j]);
  }
}

type Point = { x: number; y: number; z: number };

function rotate(x: number, y: number, z: number, w: number, xw: number, yw: number, zw: number, yz: number) {
  let c = Math.cos(xw);
  let s = Math.sin(xw);
  let nx = x * c + w * s;
  let nw = -x * s + w * c;
  x = nx;
  w = nw;

  c = Math.cos(yw);
  s = Math.sin(yw);
  const ny = y * c + w * s;
  nw = -y * s + w * c;
  y = ny;
  w = nw;

  c = Math.cos(zw);
  s = Math.sin(zw);
  const nz = z * c + w * s;
  nw = -z * s + w * c;
  z = nz;
  w = nw;

  c = Math.cos(yz);
  s = Math.sin(yz);
  const yy = y * c - z * s;
  const zz = y * s + z * c;
  return [x, yy, zz, w] as const;
}

function project(x: number, y: number, z: number, w: number): Point {
  const fold = 2.6 / (2.6 - w);
  const x3 = x * fold;
  const y3 = y * fold;
  const z3 = z * fold;
  const depth = 4.4 / (4.4 - z3);
  return { x: x3 * depth, y: y3 * depth, z: z3 };
}

export function Hypercube({ playing, compact = false }: { playing: boolean; compact?: boolean }) {
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const playingRef = useRef(playing);
  playingRef.current = playing;

  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const context = canvas.getContext("2d");
    if (!context) return;

    const reduced = window.matchMedia("(prefers-reduced-motion: reduce)").matches;
    const bins = new Uint8Array(64);
    const shelves = compact ? 2 : 4;
    let energy = 0;
    let bass = 0;
    let treble = 0;
    let phase = 0;
    let last = performance.now();
    let frame = 0;

    const draw = (now: number) => {
      const dpr = Math.min(window.devicePixelRatio || 1, 2);
      const width = canvas.clientWidth;
      const height = canvas.clientHeight;
      if (width < 2 || height < 2) {
        frame = window.requestAnimationFrame(draw);
        return;
      }
      const pixelWidth = Math.floor(width * dpr);
      const pixelHeight = Math.floor(height * dpr);
      if (canvas.width !== pixelWidth || canvas.height !== pixelHeight) {
        canvas.width = pixelWidth;
        canvas.height = pixelHeight;
      }
      context.setTransform(dpr, 0, 0, dpr, 0, 0);

      const styles = getComputedStyle(document.documentElement);
      const accent = styles.getPropertyValue("--color-accent").trim() || "#c9a36a";
      const ink = styles.getPropertyValue("--color-fg").trim() || "#f4efe6";
      const live = playingRef.current && readFrequencies(bins);
      if (live) {
        let low = 0;
        let high = 0;
        let all = 0;
        const mid = bins.length >> 1;
        for (let index = 0; index < bins.length; index += 1) {
          all += bins[index];
          if (index < mid) low += bins[index];
          else high += bins[index];
        }
        energy += (all / (bins.length * 255) - energy) * 0.18;
        bass += (low / (mid * 255) - bass) * 0.18;
        treble += (high / ((bins.length - mid) * 255) - treble) * 0.22;
      } else {
        energy += (0 - energy) * 0.04;
        bass += (0 - bass) * 0.04;
        treble += (0 - treble) * 0.04;
      }

      const dt = Math.min(0.05, (now - last) / 1000);
      last = now;
      // Music turns steadily. Bass changes weight and color, not speed.
      phase += reduced ? 0 : dt * (live ? 0.28 : 0.45);
      const time = reduced ? 1.2 : phase;

      if (!compact && !reduced) {
        context.fillStyle = "rgba(14, 13, 12, 0.28)";
        context.fillRect(0, 0, width, height);
      } else {
        context.clearRect(0, 0, width, height);
      }

      const drift = reduced ? 0 : Math.sin(time * 0.23);
      const cx = width * 0.5 + drift * width * (compact ? 0.02 : 0.06);
      const cy = height * (compact ? 0.52 : 0.48) + Math.cos(time * 0.17) * height * (compact ? 0.02 : 0.035);
      const unit = Math.min(width, height) * (compact ? 0.34 : 0.2);

      for (let shelf = shelves - 1; shelf >= 0; shelf -= 1) {
        const spin = 0.42 * (shelf % 2 === 0 ? 1 : -0.72);
        const xw = time * spin + shelf * 0.85;
        const yw = time * 0.28 + shelf * 1.55;
        const zw = time * 0.18 * (shelf % 2 === 0 ? 1 : -1) + shelf * 0.4;
        const yz = time * 0.14 + shelf * 0.7;
        const points: Point[] = [];

        for (let index = 0; index < VERTS.length; index += 1) {
          const source = VERTS[index];
          const wobble = live ? Math.sin(time * 0.45 + index * 0.7) * bass * 0.035 : 0;
          const rotated = rotate(
            source[0] + wobble,
            source[1],
            source[2] - wobble * 0.5,
            source[3],
            xw,
            yw,
            zw,
            yz,
          );
          points.push(project(rotated[0], rotated[1], rotated[2], rotated[3]));
        }

        const scale = unit * (0.62 + shelf * 0.2) * (1 + bass * 0.05);
        const shiftX = Math.sin(time * 0.31 + shelf * 1.4) * width * (compact ? 0.04 : 0.09);
        const shiftY = Math.cos(time * 0.27 + shelf) * height * (compact ? 0.08 : 0.07);
        const front = shelf === 0;
        const base = compact ? 1.1 : front ? 1.6 : 1.05;
        const tint = Math.min(1, bass * 1.7);
        context.lineCap = "round";
        context.lineJoin = "round";
        context.lineWidth = base * (1 + bass * (front ? 16 : 8));
        context.strokeStyle = shelf % 2 === 0 ? accent : ink;
        context.globalAlpha = (front ? 0.92 : 0.28 + shelf * 0.08) + energy * 0.12;

        const ordered = EDGES.map((edge) => ({
          edge,
          depth: points[edge[0]].z + points[edge[1]].z,
        }));
        ordered.sort((a, b) => a.depth - b.depth);

        for (const item of ordered) {
          const a = points[item.edge[0]];
          const b = points[item.edge[1]];
          const x1 = cx + shiftX + a.x * scale;
          const y1 = cy + shiftY + a.y * scale;
          const x2 = cx + shiftX + b.x * scale;
          const y2 = cy + shiftY + b.y * scale;
          context.beginPath();
          context.moveTo(x1, y1);
          context.lineTo(x2, y2);
          context.stroke();
          if (shelf % 2 !== 0 && tint > 0.04) {
            context.strokeStyle = accent;
            context.globalAlpha = tint * (front ? 0.9 : 0.45);
            context.lineWidth = base * (0.45 + bass * (front ? 9 : 4));
            context.stroke();
            context.strokeStyle = ink;
            context.lineWidth = base * (1 + bass * (front ? 16 : 8));
            context.globalAlpha = (front ? 0.92 : 0.28 + shelf * 0.08) + energy * 0.12;
          }
        }

        if (!compact && front) {
          context.fillStyle = accent;
          for (const point of points) {
            const size = 2.2 + energy * 2.4;
            context.fillRect(cx + shiftX + point.x * scale - size / 2, cy + shiftY + point.y * scale - size / 2, size, size);
          }
        }
      }

      context.globalAlpha = 1;
      frame = window.requestAnimationFrame(draw);
    };

    frame = window.requestAnimationFrame(draw);
    return () => window.cancelAnimationFrame(frame);
  }, [compact]);

  return (
    <canvas
      ref={canvasRef}
      className={compact ? "player-viz" : "hyper-canvas"}
      aria-hidden="true"
    />
  );
}
