import { createFileRoute } from "@tanstack/react-router";
import { useEffect, useRef, useState } from "react";
import { ProductStage } from "@/components/product-stage";
import { MusicShelf } from "@/components/music-shelf";
import { PlayerDock } from "@/components/player-dock";
import type { LightPreset, LightingState } from "@/components/stage-canvas";
import {
  MATERIALS,
  demoProduct,
  formatPrice,
  shirts,
  stagePieces,
  ventures,
  type MaterialId,
} from "@/data/catalog";

export const Route = createFileRoute("/")({ component: Home });

const BRASS_HUE = 36;

function hslToHex(hue: number, saturation: number, lightness: number) {
  const sat = saturation / 100;
  const light = lightness / 100;
  const a = sat * Math.min(light, 1 - light);
  const channel = (n: number) => {
    const k = (n + hue / 30) % 12;
    const value = light - a * Math.max(Math.min(k - 3, 9 - k, 1), -1);
    return Math.round(255 * value)
      .toString(16)
      .padStart(2, "0");
  };
  return `#${channel(0)}${channel(8)}${channel(4)}`;
}

function hexHue(hex: string) {
  const value = Number.parseInt(hex.slice(1), 16);
  if (!Number.isFinite(value)) return null;
  const red = ((value >> 16) & 255) / 255;
  const green = ((value >> 8) & 255) / 255;
  const blue = (value & 255) / 255;
  const max = Math.max(red, green, blue);
  const min = Math.min(red, green, blue);
  if (max - min < 0.08) return null;
  let hue = 0;
  if (max === red) hue = (green - blue) / (max - min);
  else if (max === green) hue = 2 + (blue - red) / (max - min);
  else hue = 4 + (red - green) / (max - min);
  return (Math.round(hue * 60) + 360) % 360;
}

function paintStudio(hue: number) {
  const root = document.documentElement;
  root.style.setProperty("--color-accent", `hsl(${hue} 46% 60%)`);
  root.style.setProperty("--color-accent-ink", `hsl(${hue} 28% 8%)`);
  root.style.setProperty("--color-fg", `hsl(${hue} 24% 94%)`);
  root.style.setProperty("--color-muted", `hsl(${hue} 10% 62%)`);
  root.style.setProperty("--color-line", `hsl(${hue} 12% 18%)`);
}

const PRESETS: Record<LightPreset, LightingState> = {
  warm: { preset: "warm", key: 2.5, fill: 0.42, rim: 1.25, env: 0.55 },
  neutral: { preset: "neutral", key: 1.85, fill: 0.7, rim: 0.85, env: 0.72 },
  cool: { preset: "cool", key: 1.55, fill: 0.95, rim: 1.45, env: 0.86 },
};

function ShirtMark({ color, hood }: { color: string; hood: boolean }) {
  return (
    <svg className="shirt-mark" viewBox="0 0 80 80" aria-hidden="true">
      <path
        fill={color}
        d={
          hood
            ? "M24 30 14 36 18 54 28 49 28 66 52 66 52 49 62 54 66 36 56 30C52 24 48 16 40 16S28 24 24 30Z"
            : "M26 28 16 34 20 48 30 44 30 66 50 66 50 44 60 48 64 34 54 28C50 22 46 18 40 18S30 22 26 28Z"
        }
      />
    </svg>
  );
}

function Home() {
  const product = demoProduct;
  const initial = product.variants[2] ?? product.variants[0];
  const [variantId, setVariantId] = useState(initial.id);
  const [material, setMaterial] = useState<MaterialId>(initial.material);
  const [size, setSize] = useState(product.sizes[1] ?? product.sizes[0]);
  const [bag, setBag] = useState(0);
  const [toast, setToast] = useState<string | null>(null);
  const [toastKey, setToastKey] = useState(0);
  const [autoRotate, setAutoRotate] = useState(true);
  const [lightsOpen, setLightsOpen] = useState(false);
  const [lighting, setLighting] = useState<LightingState>(PRESETS.warm);
  const [hue, setHue] = useState(BRASS_HUE);
  const [studioCloth, setStudioCloth] = useState(false);
  const [pieceId, setPieceId] = useState(stagePieces[0].id);
  const [showFigure, setShowFigure] = useState(true);
  const resetRef = useRef<(() => void) | null>(null);

  const variant = product.variants.find((item) => item.id === variantId) ?? product.variants[0];
  const piece = stagePieces.find((item) => item.id === pieceId) ?? stagePieces[0];
  const clothColor = studioCloth ? hslToHex(hue, 38, 46) : variant.color;

  useEffect(() => {
    paintStudio(hue);
  }, [hue]);

  useEffect(() => {
    if (window.matchMedia("(prefers-reduced-motion: reduce)").matches) {
      setAutoRotate(false);
    }
  }, []);

  useEffect(() => {
    if (!toast) return;
    const timer = window.setTimeout(() => setToast(null), 2200);
    return () => window.clearTimeout(timer);
  }, [toast, toastKey]);

  useEffect(() => {
    const onKey = (event: KeyboardEvent) => {
      const target = event.target as HTMLElement | null;
      const typing = target?.closest("input, textarea, select, [contenteditable='true']");
      if (event.key === "r" || event.key === "R") {
        if (typing) return;
        event.preventDefault();
        resetRef.current?.();
      }
      if (event.key === " ") {
        if (typing || target?.closest("button, a")) return;
        event.preventDefault();
        setAutoRotate((value) => !value);
      }
    };
    window.addEventListener("keydown", onKey);
    return () => window.removeEventListener("keydown", onKey);
  }, []);

  const addLine = (line: string) => {
    setBag((count) => count + 1);
    setToast(line);
    setToastKey((key) => key + 1);
  };

  return (
    <div className="shell">
      <header className="site-header">
        <a className="mark" href="#shop">
          AK Ai
        </a>
        <nav className="nav" aria-label="Page">
          <a href="#shop">Shop</a>
          <a href="#music">Music</a>
          <a href="#ventures">Ventures</a>
          <a href="#goods">Goods</a>
          <a href="#about">About</a>
        </nav>
        <button type="button" className="bag-btn" aria-live="polite">
          Bag {bag}
        </button>
      </header>

      <main>
        <div className="mast">
          <p className="mast-name">AKAi LLC</p>
          <div className="mast-actions">
            <a href="#shop">Shop</a>
            <a href="#goods">Goods</a>
            <a href="#music">Music</a>
            <a href="#ventures">Ventures</a>
          </div>
        </div>
        <section className="hero" id="shop" aria-label="Product stage">
          <ProductStage
            modelType={piece.modelType}
            color={clothColor}
            material={material}
            autoRotate={autoRotate}
            lighting={lighting}
            studioHue={hue}
            showFigure={piece.apparel && showFigure}
            onApi={(api) => {
              resetRef.current = api.reset;
            }}
          />

          <div className="rail rail-info">
            <div>
              <p className="eyebrow">01 / Stage</p>
              <h1 className="product-name">{piece.name}</h1>
              <p className="price">{formatPrice(piece.price, product.currency)}</p>
            </div>
            <p className="spec">{piece.spec}</p>

            <div>
              <p className="control-label" id="piece-label">
                Piece
              </p>
              <div className="materials" role="group" aria-labelledby="piece-label">
                {stagePieces.map((item) => (
                  <button
                    key={item.id}
                    type="button"
                    className="pill"
                    aria-pressed={item.id === piece.id}
                    onClick={() => {
                      setPieceId(item.id);
                      if (item.sizes.length && !item.sizes.includes(size)) {
                        setSize(item.sizes[1] ?? item.sizes[0]);
                      }
                    }}
                  >
                    {item.label}
                  </button>
                ))}
                {piece.apparel ? (
                  <button
                    type="button"
                    className="pill"
                    aria-pressed={showFigure}
                    onClick={() => setShowFigure((value) => !value)}
                  >
                    {showFigure ? "Figure" : "No figure"}
                  </button>
                ) : null}
              </div>
            </div>

            <div>
              <p className="control-label" id="color-label">
                Color
              </p>
              <div className="swatches" role="group" aria-labelledby="color-label">
                {product.variants.map((item) => (
                  <button
                    key={item.id}
                    type="button"
                    className="swatch"
                    aria-label={item.label}
                    aria-pressed={item.id === variant.id}
                    style={{ backgroundColor: item.color }}
                    onClick={() => {
                      setVariantId(item.id);
                      setStudioCloth(false);
                      const next = hexHue(item.color);
                      if (next !== null) setHue(next);
                    }}
                  />
                ))}
              </div>
            </div>

            <label className="slider-row">
              <span>Studio</span>
              <input
                type="range"
                min={0}
                max={360}
                step={1}
                value={hue}
                aria-label="Studio color"
                onChange={(event) => {
                  setHue(Number(event.target.value));
                  setStudioCloth(true);
                }}
              />
            </label>

            <div>
              <p className="control-label" id="cloth-label">
                {piece.apparel ? "Cloth" : "Surface"}
              </p>
              <div className="materials" role="group" aria-labelledby="cloth-label">
                {MATERIALS.map((item) => (
                  <button
                    key={item.id}
                    type="button"
                    className="pill"
                    aria-pressed={material === item.id}
                    onClick={() => setMaterial(item.id)}
                  >
                    {item.label}
                  </button>
                ))}
              </div>
            </div>

            {piece.sizes.length > 0 ? (
            <div>
              <p className="control-label" id="size-label">
                Size
              </p>
              <div className="sizes" role="group" aria-labelledby="size-label">
                {piece.sizes.map((item) => (
                  <button
                    key={item}
                    type="button"
                    className="pill"
                    aria-pressed={size === item}
                    onClick={() => setSize(item)}
                  >
                    {item}
                  </button>
                ))}
              </div>
            </div>
            ) : null}
          </div>

          <div className="rail rail-actions">
            <div className="action-row">
              <button
                type="button"
                className="action-btn"
                aria-pressed={autoRotate}
                onClick={() => setAutoRotate((value) => !value)}
              >
                {autoRotate ? "Spinning" : "Spin"}
              </button>
              <button
                type="button"
                className="action-btn"
                aria-expanded={lightsOpen}
                onClick={() => setLightsOpen((value) => !value)}
              >
                Lights
              </button>
              <button type="button" className="action-btn span-2" onClick={() => resetRef.current?.()}>
                Reset
              </button>
              <button type="button" className="add-btn" onClick={() => addLine(piece.apparel ? `${piece.name} · ${variant.label} · ${size}` : `${piece.name} · ${variant.label}`)}>
                Add to bag
              </button>
            </div>

            {lightsOpen ? (
              <div className="lights" role="group" aria-label="Lighting">
                <div className="presets">
                  {(Object.keys(PRESETS) as LightPreset[]).map((preset) => (
                    <button
                      key={preset}
                      type="button"
                      className="pill"
                      aria-pressed={lighting.preset === preset}
                      onClick={() => setLighting(PRESETS[preset])}
                    >
                      {preset}
                    </button>
                  ))}
                </div>
                <Slider
                  label="Key"
                  value={lighting.key}
                  max={4}
                  onChange={(key) => setLighting((state) => ({ ...state, key }))}
                />
                <Slider
                  label="Fill"
                  value={lighting.fill}
                  max={2}
                  onChange={(fill) => setLighting((state) => ({ ...state, fill }))}
                />
                <Slider
                  label="Rim"
                  value={lighting.rim}
                  max={3}
                  onChange={(rim) => setLighting((state) => ({ ...state, rim }))}
                />
                <Slider
                  label="Env"
                  value={lighting.env}
                  max={2}
                  onChange={(env) => setLighting((state) => ({ ...state, env }))}
                />
              </div>
            ) : null}

            <p className="key-hint">R reset · Space spin</p>
          </div>
        </section>

        <MusicShelf onAdd={addLine} />

        <section className="section" id="ventures">
          <div className="section-head">
            <p className="eyebrow">03 / Ventures</p>
            <h2>Several businesses. One shell.</h2>
          </div>
          <ul className="venture-grid">
            {ventures.map((venture) => (
              <li key={venture.id} className="venture-card">
                <p className="status" data-status={venture.status}>
                  {venture.status}
                </p>
                <h3>{venture.name}</h3>
                <p>{venture.pitch}</p>
                <a className="card-cta" href={venture.href}>
                  {venture.cta}
                </a>
              </li>
            ))}
          </ul>
        </section>

        <section className="section" id="goods" aria-label="Products">
          <div className="section-head">
            <p className="eyebrow">04 / Goods</p>
            <h2>Shirts.</h2>
          </div>
          <ul className="goods">
            {shirts.map((item) => (
              <li key={item.id}>
                <a
                  className="goods-tile"
                  href="#shop"
                  onClick={() => {
                    setPieceId(item.pieceId);
                    setVariantId(item.variantId);
                    setStudioCloth(false);
                    const next = product.variants.find((entry) => entry.id === item.variantId);
                    if (next) {
                      setMaterial(next.material);
                      const hue = hexHue(next.color);
                      if (hue !== null) setHue(hue);
                    }
                  }}
                >
                  <span className="goods-square">
                    <ShirtMark color={item.color} hood={item.pieceId === "hoodie"} />
                  </span>
                  <span className="goods-name">{item.name}</span>
                  <span className="goods-price">{formatPrice(item.price, product.currency)}</span>
                </a>
              </li>
            ))}
          </ul>
        </section>

        <section className="section" id="about">
          <div className="section-head">
            <p className="eyebrow">05 / About</p>
          </div>
          <div className="about-lines">
            <p>A studio for more than one business.</p>
            <p>The work on the table is real.</p>
            <p>The next idea does not need a new site.</p>
          </div>
        </section>
      </main>

      <footer className="site-footer">
        <span>AK Ai</span>
        <span>2026</span>
      </footer>

      <PlayerDock />

      {toast ? (
        <div className="toast" role="status" key={toastKey}>
          {toast}
        </div>
      ) : null}
    </div>
  );
}

function Slider({
  label,
  value,
  max,
  onChange,
}: {
  label: string;
  value: number;
  max: number;
  onChange: (value: number) => void;
}) {
  return (
    <label className="slider-row">
      <span>{label}</span>
      <input
        type="range"
        min={0}
        max={max}
        step={0.05}
        value={value}
        aria-label={label}
        onChange={(event) => onChange(Number(event.target.value))}
      />
    </label>
  );
}
