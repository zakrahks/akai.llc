# Tesser

A hypercube music visualizer. One file. Drop it on any site.

Files:

- `tesser.js` — the widget
- `index.html` — a full-page demo. Serve this folder (opening the HTML as a file works for the cube; mic and remote audio need https)

## Drop-in

```html
<div data-tesser data-mode="hyper" data-theme="glacier" style="width:100%;height:480px"></div>
<script src="tesser.js"></script>
```

Leave off `data-theme` and `data-color` and it samples the host page (`--accent`, `--brand`, `--primary`, or the page background).

## Mount it yourself

```html
<div id="viz" style="height:480px"></div>
<script src="tesser.js"></script>
<script>
  const viz = Tesser.mount("#viz", {
    mode: "hyper",       // "hyper" | "bars" | "ring"
    theme: "glacier",    // glacier, copper, signal, canopy, ink
    sensitivity: 1.15,
    follow: true,
    bounce: true,
    speed: 1,
    controls: true,
    adapt: true
    // color: "#e3946a",
    // background: "#1c1917",
    // src: "https://cdn.example.com/song.mp3"
  });
</script>
```

Custom look without a preset: `color` is the edge, `background` is the field. Or pass `theme: { bg, edge, core, hot }`.

## Attributes

`data-mode` hyper | bars | ring
`data-theme` glacier | copper | signal | canopy | ink
`data-color` `#e3946a`
`data-background` `#07080b`
`data-src` remote audio URL
`data-sensitivity` 0.2–3
`data-speed` 0.25–3
`data-radius` cube size, about 0.19
`data-follow` `false` to stop chasing the pointer
`data-bounce` `false` to stop wall bounces
`data-controls` `false` hides the dock
`data-title` `false` hides the name
`data-adapt` `false` keeps the preset instead of sampling the page
`data-transparent` `true`
`data-autoplay` `true` (browsers still wait for a tap)
`data-embed` `true` starts in embed chrome

## From the parent page

```js
frame.contentWindow.postMessage(
  { type: "tesser", action: "setMode", mode: "ring" },
  "*"
);
```

Actions: `setMode`, `setTheme`, `setSensitivity`, `setColor`, `setBackground`, `setFollow`, `setBounce`, `setSpeed`, `loadUrl`, `play`, `pause`, `toggle`, `mic`, `stopMic`.

It answers `{ type: "tesser", event }` with `ready`, `mode`, `play`, `pause`, `mic`, `error`.

The mount handle has the same methods, plus `getState()` and `destroy()`.

## Audio

A file the visitor uploads always works. A URL only plays if that server sends `Access-Control-Allow-Origin`. Microphone needs a click. Keyboard: Space play/pause, M mic, F fullscreen, 1 hypercube, 2 bars, 3 ring.
