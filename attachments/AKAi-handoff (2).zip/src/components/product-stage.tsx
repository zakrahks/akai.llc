import { useEffect, useRef, useState } from "react";
import { mountStage, type StageProps } from "@/components/stage-canvas";

export function ProductStage(props: StageProps) {
  const host = useRef<HTMLDivElement>(null);
  const propsRef = useRef(props);
  propsRef.current = props;
  const [ready, setReady] = useState(false);

  useEffect(() => {
    const node = host.current;
    if (!node) return;
    return mountStage(node, propsRef, () => setReady(true));
  }, []);

  return (
    <div className="stage">
      <div ref={host} className="stage-host" data-ready={ready ? "true" : "false"} />
    </div>
  );
}