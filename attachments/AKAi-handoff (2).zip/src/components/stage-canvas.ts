import * as THREE from "three";
import { OrbitControls } from "three/addons/controls/OrbitControls.js";
import { RoomEnvironment } from "three/addons/environments/RoomEnvironment.js";
import type { MaterialId, ModelType } from "@/data/catalog";

export type LightPreset = "warm" | "neutral" | "cool";

export type LightingState = {
  preset: LightPreset;
  key: number;
  fill: number;
  rim: number;
  env: number;
};

export type StageProps = {
  modelType: ModelType;
  color: string;
  material: MaterialId;
  autoRotate: boolean;
  lighting: LightingState;
  /** 0–360. Tints the key light so the garment reads in the studio hue. */
  studioHue: number;
  /** Plaster neck and head. Ignored for objects that are not worn. */
  showFigure: boolean;
  onApi: (api: { reset: () => void }) => void;
};

const PRESET_COLORS: Record<LightPreset, { key: number; fill: number; rim: number }> = {
  warm: { key: 0xffe0b8, fill: 0xb7c6dc, rim: 0xfff1d4 },
  neutral: { key: 0xf4f0ea, fill: 0xd5d8e0, rim: 0xffffff },
  cool: { key: 0xd5e4f8, fill: 0x9aafc6, rim: 0xeef6ff },
};

const HOME_POS = new THREE.Vector3(0.4, 1.02, 5.05);
const HOME_TARGET = new THREE.Vector3(0, 0.95, 0);

function applyCloth(mat: THREE.MeshPhysicalMaterial, color: string, kind: MaterialId) {
  mat.color.set(color);
  if (kind === "cotton") {
    mat.roughness = 0.92;
    mat.metalness = 0;
    mat.sheen = 0.18;
    mat.sheenRoughness = 0.82;
    mat.sheenColor.set(color).offsetHSL(0, -0.04, 0.12);
    mat.clearcoat = 0;
    mat.clearcoatRoughness = 1;
  } else {
    mat.roughness = 0.7;
    mat.metalness = 0.02;
    mat.sheen = 0.58;
    mat.sheenRoughness = 0.38;
    mat.sheenColor.set("#f7f2e8");
    mat.clearcoat = 0.08;
    mat.clearcoatRoughness = 0.68;
  }
  mat.transmission = 0;
  mat.needsUpdate = true;
}

function discTexture() {
  const canvas = document.createElement("canvas");
  canvas.width = 256;
  canvas.height = 256;
  const ctx = canvas.getContext("2d");
  if (!ctx) return null;
  const grad = ctx.createRadialGradient(128, 128, 16, 128, 128, 122);
  grad.addColorStop(0, "rgba(255, 232, 204, 0.2)");
  grad.addColorStop(1, "rgba(255, 232, 204, 0)");
  ctx.fillStyle = grad;
  ctx.fillRect(0, 0, 256, 256);
  const tex = new THREE.CanvasTexture(canvas);
  tex.colorSpace = THREE.SRGBColorSpace;
  return tex;
}

function buildProduct(
  modelType: ModelType,
  cloth: THREE.Material,
  plaster: THREE.Material,
  showFigure: boolean,
) {
  const group = new THREE.Group();
  group.rotation.y = 0.62;
  const geometries: THREE.BufferGeometry[] = [];

  const add = (mesh: THREE.Mesh) => {
    mesh.castShadow = true;
    mesh.receiveShadow = true;
    group.add(mesh);
    return mesh;
  };

  const box = (w: number, h: number, d: number, x: number, y: number, z: number, material: THREE.Material, rotZ = 0) => {
    const geo = new THREE.BoxGeometry(w, h, d);
    geometries.push(geo);
    const mesh = add(new THREE.Mesh(geo, material));
    mesh.position.set(x, y, z);
    mesh.rotation.z = rotZ;
    return mesh;
  };

  const cyl = (radiusTop: number, radiusBottom: number, height: number, y: number, material: THREE.Material) => {
    const geo = new THREE.CylinderGeometry(radiusTop, radiusBottom, height, 28);
    geometries.push(geo);
    const mesh = add(new THREE.Mesh(geo, material));
    mesh.position.set(0, y, 0);
    return mesh;
  };

  if (modelType === "vessel") {
    cyl(0.32, 0.28, 0.1, 0.22, cloth);
    cyl(0.46, 0.3, 0.72, 0.62, cloth);
    cyl(0.18, 0.4, 0.26, 1.08, cloth);
    cyl(0.1, 0.12, 0.3, 1.34, cloth);
    const lipGeo = new THREE.TorusGeometry(0.12, 0.028, 10, 28);
    geometries.push(lipGeo);
    const lip = add(new THREE.Mesh(lipGeo, cloth));
    lip.rotation.x = Math.PI / 2;
    lip.position.set(0, 1.5, 0);
    return { group, geometries };
  }

  const bodyW = modelType === "hoodie" ? 0.68 : 0.62;
  const bodyH = modelType === "hoodie" ? 0.84 : 0.72;
  box(bodyW, bodyH, 0.34, 0, 0.86, 0, cloth);
  box(bodyW + 0.26, 0.14, 0.36, 0, 1.26, 0, cloth);
  box(bodyW + 0.06, 0.09, 0.36, 0, 0.4, 0, cloth);

  const sleeveH = modelType === "hoodie" ? 0.56 : 0.26;
  const sleeveY = modelType === "hoodie" ? 0.94 : 1.1;
  const sleeveRot = modelType === "hoodie" ? 0.38 : 0.65;
  box(0.18, sleeveH, 0.18, 0.5, sleeveY, 0.02, cloth, -sleeveRot);
  box(0.18, sleeveH, 0.18, -0.5, sleeveY, 0.02, cloth, sleeveRot);

  if (modelType === "hoodie") {
    box(0.44, 0.42, 0.14, 0, 1.68, -0.16, cloth);
    box(0.44, 0.1, 0.38, 0, 1.92, -0.02, cloth);
    box(0.08, 0.38, 0.32, -0.19, 1.68, 0.02, cloth);
    box(0.08, 0.38, 0.32, 0.19, 1.68, 0.02, cloth);
    box(0.3, 0.14, 0.05, 0, 0.72, 0.19, cloth);
    box(0.018, 0.34, 0.018, -0.045, 1.26, 0.2, cloth);
    box(0.018, 0.34, 0.018, 0.045, 1.26, 0.2, cloth);
  } else {
    const collar = new THREE.TorusGeometry(0.11, 0.02, 10, 28);
    geometries.push(collar);
    const ring = add(new THREE.Mesh(collar, cloth));
    ring.rotation.x = Math.PI / 2;
    ring.position.set(0, 1.44, 0.02);
  }

  if (showFigure) {
    const neckGeo = new THREE.CylinderGeometry(0.065, 0.08, 0.14, 20);
    geometries.push(neckGeo);
    const neck = add(new THREE.Mesh(neckGeo, plaster));
    neck.position.set(0, 1.46, 0.03);

    const headGeo = new THREE.SphereGeometry(0.145, 28, 20);
    geometries.push(headGeo);
    const head = add(new THREE.Mesh(headGeo, plaster));
    head.scale.set(1, 1.12, 0.88);
    head.position.set(0, 1.68, 0.07);
  }

  return { group, geometries };
}

export function mountStage(
  el: HTMLElement,
  propsRef: { current: StageProps },
  onFirstFrame: () => void,
) {
  const renderer = new THREE.WebGLRenderer({ antialias: true, alpha: false, powerPreference: "high-performance" });
  renderer.setPixelRatio(Math.min(window.devicePixelRatio || 1, 2));
  renderer.setSize(el.clientWidth || 1, el.clientHeight || 1);
  renderer.outputColorSpace = THREE.SRGBColorSpace;
  renderer.toneMapping = THREE.ACESFilmicToneMapping;
  renderer.toneMappingExposure = 1.12;
  renderer.shadowMap.enabled = true;
  renderer.shadowMap.type = THREE.PCFShadowMap;
  renderer.domElement.setAttribute("aria-label", "3D product stage. Drag to orbit. Scroll or pinch to zoom.");
  el.appendChild(renderer.domElement);

  const scene = new THREE.Scene();
  scene.background = new THREE.Color("#0e0d0c");

  const camera = new THREE.PerspectiveCamera(34, 1, 0.1, 40);
  camera.position.copy(HOME_POS);

  const controls = new OrbitControls(camera, renderer.domElement);
  controls.target.copy(HOME_TARGET);
  controls.enableDamping = true;
  controls.dampingFactor = 0.08;
  controls.enablePan = false;
  controls.rotateSpeed = 0.7;
  controls.zoomSpeed = 0.65;
  controls.minDistance = 2.5;
  controls.maxDistance = 6.2;
  controls.minPolarAngle = 0.78;
  controls.maxPolarAngle = Math.PI / 2.05;
  controls.autoRotateSpeed = 0.6;
  controls.update();

  const pmrem = new THREE.PMREMGenerator(renderer);
  scene.environment = pmrem.fromScene(new RoomEnvironment(), 0.04).texture;
  scene.environmentIntensity = propsRef.current.lighting.env;

  const key = new THREE.DirectionalLight(PRESET_COLORS.warm.key, propsRef.current.lighting.key);
  key.position.set(2.6, 3.6, 2.4);
  key.castShadow = true;
  key.shadow.mapSize.set(1024, 1024);
  key.shadow.camera.near = 0.5;
  key.shadow.camera.far = 12;
  key.shadow.camera.left = -2.4;
  key.shadow.camera.right = 2.4;
  key.shadow.camera.top = 2.4;
  key.shadow.camera.bottom = -2.4;
  key.shadow.bias = -0.001;
  scene.add(key);

  const fill = new THREE.DirectionalLight(PRESET_COLORS.warm.fill, propsRef.current.lighting.fill);
  fill.position.set(-2.8, 1.6, 2);
  scene.add(fill);

  const rim = new THREE.DirectionalLight(PRESET_COLORS.warm.rim, propsRef.current.lighting.rim);
  const studioTint = new THREE.Color();
  rim.position.set(-0.2, 2.6, -3);
  scene.add(rim);

  scene.add(new THREE.AmbientLight(0xffffff, 0.16));
  scene.add(new THREE.HemisphereLight(0xf4ebdd, 0x161310, 0.32));

  const floor = new THREE.Mesh(
    new THREE.CircleGeometry(2.6, 48),
    new THREE.MeshStandardMaterial({ color: "#100e0c", roughness: 1, metalness: 0 }),
  );
  floor.rotation.x = -Math.PI / 2;
  floor.receiveShadow = true;
  scene.add(floor);

  const ring = new THREE.Mesh(
    new THREE.TorusGeometry(0.78, 0.008, 8, 72),
    new THREE.MeshBasicMaterial({ color: "#3a342c" }),
  );
  ring.rotation.x = -Math.PI / 2;
  ring.position.y = 0.015;
  scene.add(ring);

  const glowMap = discTexture();
  let glow: THREE.Mesh | null = null;
  if (glowMap) {
    glow = new THREE.Mesh(
      new THREE.CircleGeometry(1.15, 40),
      new THREE.MeshBasicMaterial({ map: glowMap, transparent: true, depthWrite: false }),
    );
    glow.rotation.x = -Math.PI / 2;
    glow.position.y = 0.01;
    scene.add(glow);
  }

  const cloth = new THREE.MeshPhysicalMaterial({ color: propsRef.current.color });
  applyCloth(cloth, propsRef.current.color, propsRef.current.material);
  const plaster = new THREE.MeshPhysicalMaterial({
    color: "#aeb6c0",
    roughness: 0.72,
    metalness: 0,
    clearcoat: 0.08,
    clearcoatRoughness: 0.55,
  });

  let built = buildProduct(propsRef.current.modelType, cloth, plaster, propsRef.current.showFigure);
  let modelType = propsRef.current.modelType;
  let figureOn = propsRef.current.showFigure;
  scene.add(built.group);

  let dragging = false;
  const onStart = () => {
    dragging = true;
  };
  const onEnd = () => {
    dragging = false;
  };
  controls.addEventListener("start", onStart);
  controls.addEventListener("end", onEnd);

  const reset = () => {
    camera.position.copy(HOME_POS);
    controls.target.copy(HOME_TARGET);
    controls.update();
  };
  propsRef.current.onApi({ reset });

  const resize = () => {
    const w = Math.max(el.clientWidth, 1);
    const h = Math.max(el.clientHeight, 1);
    camera.aspect = w / h;
    camera.updateProjectionMatrix();
    renderer.setSize(w, h, false);
  };
  const observer = new ResizeObserver(resize);
  observer.observe(el);
  resize();

  let first = true;
  let applied = "";
  renderer.setAnimationLoop(() => {
    const props = propsRef.current;
    if (props.modelType !== modelType || props.showFigure !== figureOn) {
      scene.remove(built.group);
      built.geometries.forEach((geo) => geo.dispose());
      built = buildProduct(props.modelType, cloth, plaster, props.showFigure);
      modelType = props.modelType;
      figureOn = props.showFigure;
      scene.add(built.group);
      applied = "";
    }

    const sig = `${props.color}|${props.material}`;
    if (sig !== applied) {
      applyCloth(cloth, props.color, props.material);
      applied = sig;
    }

    const colors = PRESET_COLORS[props.lighting.preset];
    const hue = ((props.studioHue % 360) + 360) % 360;
    studioTint.setHSL(hue / 360, 0.48, 0.7);
    key.color.setHex(colors.key).lerp(studioTint, 0.7);
    fill.color.setHex(colors.fill);
    rim.color.setHex(colors.rim);
    key.intensity = props.lighting.key;
    fill.intensity = props.lighting.fill;
    rim.intensity = props.lighting.rim;
    scene.environmentIntensity = props.lighting.env;

    controls.autoRotate = props.autoRotate && !dragging;
    controls.update();
    renderer.render(scene, camera);
    if (first) {
      first = false;
      onFirstFrame();
    }
  });

  return () => {
    renderer.setAnimationLoop(null);
    observer.disconnect();
    controls.removeEventListener("start", onStart);
    controls.removeEventListener("end", onEnd);
    controls.dispose();
    built.geometries.forEach((geo) => geo.dispose());
    cloth.dispose();
    plaster.dispose();
    floor.geometry.dispose();
    (floor.material as THREE.Material).dispose();
    ring.geometry.dispose();
    (ring.material as THREE.Material).dispose();
    glow?.geometry.dispose();
    (glow?.material as THREE.Material | undefined)?.dispose();
    glowMap?.dispose();
    scene.environment?.dispose();
    pmrem.dispose();
    renderer.dispose();
    renderer.domElement.remove();
  };
}
