import { useState } from "react";
import { Pause, Play, SkipBack, SkipForward } from "lucide-react";
import { ARTIST, releases } from "@/data/tracks";
import { Hypercube } from "@/components/hypercube";
import {
  releaseById,
  seekPlayback,
  setPlaybackVolume,
  stepRelease,
  togglePlayback,
  usePlayer,
} from "@/components/player-store";

function formatTime(seconds: number) {
  if (!Number.isFinite(seconds) || seconds < 0) return "0:00";
  const whole = Math.floor(seconds);
  const minutes = Math.floor(whole / 60);
  const remain = whole % 60;
  return `${minutes}:${remain.toString().padStart(2, "0")}`;
}

export function PlayerDock() {
  const activeId = usePlayer((state) => state.activeId);
  const playing = usePlayer((state) => state.playing);
  const currentTime = usePlayer((state) => state.currentTime);
  const duration = usePlayer((state) => state.duration);
  const volume = usePlayer((state) => state.volume);
  const message = usePlayer((state) => state.message);
  const [open, setOpen] = useState(false);
  const active = releaseById(activeId);

  const title = active?.title ?? "Shelf empty";
  const detail =
    message ??
    (active
      ? `${active.artist} · ${active.kind}`
      : releases.length === 0
        ? `${ARTIST.name} · catalog empty`
        : ARTIST.name);

  return (
    <section className={open ? "player-dock is-open" : "player-dock"} aria-label="Music player">
      <div className="player-main">
        <div className="player-transport">
          <button type="button" className="icon-btn player-skip" aria-label="Previous" onClick={() => stepRelease(-1)}>
            <SkipBack size={16} strokeWidth={1.5} />
          </button>
          <button
            type="button"
            className="icon-btn"
            aria-label={playing ? "Pause" : "Play"}
            aria-pressed={playing}
            onClick={() => togglePlayback()}
          >
            {playing ? <Pause size={16} strokeWidth={1.5} /> : <Play size={16} strokeWidth={1.5} />}
          </button>
          <button type="button" className="icon-btn player-skip" aria-label="Next" onClick={() => stepRelease(1)}>
            <SkipForward size={16} strokeWidth={1.5} />
          </button>
        </div>

        <div className="player-meta">
          <p className="player-title">
            <span>{title}</span>
            <span className="player-time">
              {formatTime(currentTime)} / {formatTime(duration)}
            </span>
          </p>
          <p className="player-sub" aria-live="polite">
            {detail}
          </p>
        </div>

        <Hypercube playing={playing} compact />

        <button
          type="button"
          className="action-btn player-audio"
          aria-expanded={open}
          onClick={() => setOpen((value) => !value)}
        >
          Audio
        </button>
      </div>

      {open ? (
        <div className="player-panel">
          <label className="slider-row">
            <span>Seek</span>
            <input
              type="range"
              min={0}
              max={duration || 0}
              step={0.1}
              value={Math.min(currentTime, duration || 0)}
              aria-label="Seek"
              disabled={!duration}
              onChange={(event) => seekPlayback(Number(event.target.value))}
            />
          </label>
          <label className="slider-row">
            <span>Vol</span>
            <input
              type="range"
              min={0}
              max={1}
              step={0.01}
              value={volume}
              aria-label="Volume"
              onChange={(event) => setPlaybackVolume(Number(event.target.value))}
            />
          </label>
        </div>
      ) : null}
    </section>
  );
}
